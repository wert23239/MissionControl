# Meet X Marker

Chrome extension for Google Meet that lets a group mark who has already gone.

## What it does

- Adds a floating panel to `meet.google.com`.
- Detects visible participant names where possible.
- Lets users manually add names if Meet hides a participant from the DOM.
- Syncs X marks by meeting code through Supabase.
- Shows inline X badges on matching Meet elements when it can safely match a name.

Everyone who wants to see the marks inside Google Meet needs the extension installed.

## Local install

1. Open `chrome://extensions`.
2. Enable **Developer mode**.
3. Click **Load unpacked**.
4. Select this folder: `google-meet-x-marker`.
5. Open a Google Meet URL.

## Chrome Web Store

For the group install path, publish as an unlisted or public Chrome Web Store extension.

Public-store prep files:

- `store-assets/listing.md`
- `store-assets/privacy.md`
- `tmp/screenshots/meet-x-marker-panel.png`

Listing notes:

- Purpose: coordinate turn-taking in Google Meet.
- Permissions: access to `meet.google.com` and the Supabase sync endpoint.
- Data stored: meeting code, participant display name, marked/unmarked status, anonymous extension user label, and update time.
- No audio, video, chat content, or Google account data is collected.

Before public submission:

- Live-test inside a real Google Meet call.
- Replace or supplement the mock screenshot with a real or polished store screenshot.
- Publish the privacy policy at a stable URL for the Chrome Web Store form.
- Submit through a Chrome Web Store developer account.

## Supabase

The extension uses table `public.meet_x_marks` in the existing Supabase project.

Columns:

- `meeting_id`
- `participant_key`
- `participant_name`
- `marked`
- `marked_by`
- `updated_at`

RLS is enabled with anonymous read/write policies so installed clients can sync marks.
