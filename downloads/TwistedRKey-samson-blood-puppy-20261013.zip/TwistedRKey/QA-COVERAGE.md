# Isaac resumed QA — final handoff, October 13, 2026

**Targeted playtest build, NOT full acceptance.** Supported tested runtime: Repentance+ 1.9.7.12/J273 with REPENTOGON 1.1.3. Use the official launcher. No saves, audio configuration, QA helpers, experimental arenas or runtime binaries are included.

## Verified in the native game

- Panic Needle hits on floors 1–3, healing, ordinary damage-up, cold Continue and Twisted reset; later natural floor-3 transition/hits accepted separately.
- Clicker exclusion tested through pool/acquisition fixtures; repeated resets and acquired-item exclusions have targeted evidence, not exhaustive pickup history certification.
- Boss reward matrix/late bosses, Mega Satan/Void, Boss Rush and ten-check Hard-chain checkpoints have native fixture evidence. Scripted stages, boss damage and teleports are not organic complete-run certification.
- Same ten-check Samson chain: native ascent, Home bed, night Home, safe native doors and cold Continue. Black pause checks observed.
- Magdalene four-room conversion and targeted Continue; Cain/Judas targeted locks/input/reset/Continue. Judas reset retaining an active card is a known FAIL.
- Cursed Bow: nine valid native health/grant checks. Undead Bird: current/next-room lifetime and repaired pursuit with three bird-caused hits.
- Forced Resurrection: actual final-boss clean award caused native revival and subsequent native floor transition; separately, a QA-configured zero-spare-life form reached native game over. NOT natural depletion of lives.
- Five saved-design required-grant cases (Blue Baby, Eden, Bethany, Tainted Lost, Tainted Eden), production setup called twice with native inventories. NOT full inventory or organic character runs.

## Blocked, failed or still unverified

- **Native Dogma appearance crashes with NULL RoomData in the preserved native Home fixture, even without assist.** Root cause/transition target unknown. No successful Beast finale, eleven-check badge award or permanent menu badge flow certified. Beast-LAST Home gate remains the approved fallback; it does not fix this crash.
- Changed Bird Continue/key reset/next-room damage; Lazarus XL first-boss ordering and Continue/reset combinations; remaining character mechanics/twins and fresh per-character runs.
- Exact duplicate starting-kit multiplicity: ownership-gated restoration collapses duplicate copies to one (source characterization, not native-reproduced).
- Judas active-card stripping FAIL; timer reset and exhaustive collected-then-lost pickup-history exclusions unfinished. Several saved drafts remain design/partial implementation, not certified.
- Original pre-0002 living-chain mod-data backup gap remains unresolved. Later restoration audits cannot retroactively prove that original state.

## Package boundary and preservation

Includes native-tested Bird movement fix and text-only Forced Resurrection timing clarification (EID display not reverified). **Deferred Cain render-input candidate is EXCLUDED**: package uses previously shipped character_mechanics.lua. The local candidate is retained in source, not certified. Final ZIP syntax/contracts are source checks, not a new cold launch of the assembled archive.

Final read-only Windows audit against entering 20:32 backup: **70 files checked, zero SHA-256 mismatches; game closed; QA helper absent**. No Windows writes this final lane. Supported runtime/audio/options preserved by prior audited restore. Do not retry the identical TV fixture or load development helpers.

Full chronological evidence: https://github.com/wert23239/TwistedRKey/blob/main/PLAYTEST-20261012.md

Install: extract TwistedRKey into mods, replace the older copy (no duplicate enabled mod), use official REPENTOGON launcher and a fresh Hard run. Back up saves. Treat this as a targeted test release, not a fully completed mod.

## 22:48 Samson update
Blood Puppy (565) added to Samson. Setup/reapply/inventory-clear restoration passed mocked composition checks; new loadout not tested in-game. Earlier coverage applies to the previous loadout. Beast remains deferred.
