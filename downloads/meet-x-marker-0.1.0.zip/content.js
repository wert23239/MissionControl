(() => {
  const SUPABASE_URL = "https://aihworyfcgstwbpzkzoy.supabase.co";
  const SUPABASE_ANON_KEY =
    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFpaHdvcnlmY2dzdHdicHprem95Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzExMjE0NzEsImV4cCI6MjA4NjY5NzQ3MX0.NrYtMgZ3D5VL-ES6iGXrmg-WEb-fRgU4AHKnLuhcTlE";
  const TABLE = "meet_x_marks";
  const POLL_MS = 1800;
  const SCRAPE_MS = 1200;

  const blockedNameFragments = [
    "activities",
    "add others",
    "camera",
    "captions",
    "change layout",
    "chat",
    "close",
    "copy joining",
    "end call",
    "google meet",
    "hand",
    "host controls",
    "leave call",
    "meeting details",
    "microphone",
    "more options",
    "people",
    "present now",
    "raise hand",
    "reactions",
    "settings",
    "turn off",
    "turn on",
    "you are presenting"
  ];

  const state = {
    collapsed: false,
    customNames: new Set(),
    detectedNames: new Set(),
    marks: new Map(),
    meetingId: getMeetingId(),
    syncStatus: "Starting",
    userLabel: getUserLabel(),
    writeInFlight: false
  };

  let root;
  let body;
  let countEl;
  let statusEl;
  let lastRendered = "";

  function getMeetingId() {
    const match = location.pathname.match(/[a-z]{3}-[a-z]{4}-[a-z]{3}/i);
    if (match) return match[0].toLowerCase();
    return location.pathname.replace(/[^a-z0-9-]/gi, "-").replace(/^-+|-+$/g, "") || "unknown-meet";
  }

  function getUserLabel() {
    const stored = localStorage.getItem("meet-x-marker-user-label");
    if (stored) return stored;
    const label = `user-${Math.random().toString(36).slice(2, 8)}`;
    localStorage.setItem("meet-x-marker-user-label", label);
    return label;
  }

  function headers(extra = {}) {
    return {
      apikey: SUPABASE_ANON_KEY,
      Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
      "Content-Type": "application/json",
      ...extra
    };
  }

  function normalizeName(input) {
    if (!input) return "";
    let name = String(input)
      .replace(/\s+/g, " ")
      .replace(/\((you|presenting)\)/gi, "")
      .replace(/\b(is )?(muted|unmuted|presenting|speaking|pinned)\b/gi, "")
      .replace(/\b(camera|microphone) (is )?(on|off)\b/gi, "")
      .replace(/\bmore options\b/gi, "")
      .replace(/[•|]+/g, " ")
      .trim();

    name = name.split(",")[0].trim();
    name = name.replace(/^you$/i, "You").trim();

    if (name.length < 2 || name.length > 80) return "";
    if (!/[a-z]/i.test(name)) return "";
    if (/https?:\/\//i.test(name)) return "";
    if (/^[a-z]{3}-[a-z]{4}-[a-z]{3}$/i.test(name)) return "";

    const lower = name.toLowerCase();
    if (lower === "participant" || lower === "participants") return "";
    if (blockedNameFragments.some((fragment) => lower.includes(fragment))) return "";

    return name;
  }

  function participantKey(name) {
    return normalizeName(name).toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
  }

  function scrapeParticipants() {
    const names = new Set();

    document.querySelectorAll("[data-self-name]").forEach((el) => {
      if (isOwnUi(el)) return;
      const name = normalizeName(el.getAttribute("data-self-name"));
      if (name) names.add(name);
    });

    document.querySelectorAll("[aria-label]").forEach((el) => {
      if (isOwnUi(el)) return;
      const label = el.getAttribute("aria-label");
      const name = normalizeName(label);
      if (name && looksLikeParticipantElement(el, label)) names.add(name);
    });

    document.querySelectorAll("div, span").forEach((el) => {
      if (isOwnUi(el)) return;
      if (!isLikelyVisible(el)) return;
      const text = normalizeName(el.textContent);
      if (!text) return;
      if (text.split(" ").length > 5) return;
      if (el.children.length > 2) return;
      if (nearMeetControls(el)) return;
      names.add(text);
    });

    state.detectedNames = names;
    render();
    paintBadges();
  }

  function looksLikeParticipantElement(el, label) {
    const lower = String(label).toLowerCase();
    if (blockedNameFragments.some((fragment) => lower.includes(fragment))) return false;
    if (lower.includes("participant") || lower.includes("muted") || lower.includes("speaking")) return true;
    const rect = el.getBoundingClientRect();
    return rect.width > 80 && rect.height > 20 && rect.top > 0 && rect.left > 0;
  }

  function isLikelyVisible(el) {
    const rect = el.getBoundingClientRect();
    const style = window.getComputedStyle(el);
    return rect.width > 8 && rect.height > 8 && style.visibility !== "hidden" && style.display !== "none";
  }

  function isOwnUi(el) {
    return Boolean(el.closest("#meet-x-marker-root") || el.classList.contains("gmx-inline-badge"));
  }

  function nearMeetControls(el) {
    const text = `${el.textContent || ""} ${el.getAttribute("aria-label") || ""}`.toLowerCase();
    return blockedNameFragments.some((fragment) => text.includes(fragment));
  }

  async function fetchMarks() {
    const query = new URLSearchParams({
      meeting_id: `eq.${state.meetingId}`,
      select: "participant_key,participant_name,marked,marked_by,updated_at"
    });
    const url = `${SUPABASE_URL}/rest/v1/${TABLE}?${query.toString()}`;

    try {
      const response = await fetch(url, { headers: headers() });
      if (!response.ok) throw new Error(`Fetch failed ${response.status}`);
      const rows = await response.json();
      state.marks = new Map(rows.map((row) => [row.participant_key, row]));
      state.syncStatus = `Synced ${new Date().toLocaleTimeString([], { hour: "numeric", minute: "2-digit", second: "2-digit" })}`;
      render();
      paintBadges();
    } catch (error) {
      state.syncStatus = "Sync offline";
      render();
    }
  }

  async function setMarked(name, marked) {
    const cleanName = normalizeName(name);
    const key = participantKey(cleanName);
    if (!key || state.writeInFlight) return;

    state.writeInFlight = true;
    state.marks.set(key, {
      participant_key: key,
      participant_name: cleanName,
      marked,
      marked_by: state.userLabel,
      updated_at: new Date().toISOString()
    });
    render();
    paintBadges();

    const payload = {
      meeting_id: state.meetingId,
      participant_key: key,
      participant_name: cleanName,
      marked,
      marked_by: state.userLabel,
      updated_at: new Date().toISOString()
    };

    try {
      const response = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}`, {
        method: "POST",
        headers: headers({ Prefer: "resolution=merge-duplicates,return=minimal" }),
        body: JSON.stringify(payload)
      });
      if (!response.ok) throw new Error(`Save failed ${response.status}`);
      state.syncStatus = "Saved";
      await fetchMarks();
    } catch (error) {
      state.syncStatus = "Save failed";
      render();
    } finally {
      state.writeInFlight = false;
    }
  }

  async function resetMeeting() {
    const query = new URLSearchParams({ meeting_id: `eq.${state.meetingId}` });
    try {
      const response = await fetch(`${SUPABASE_URL}/rest/v1/${TABLE}?${query.toString()}`, {
        method: "DELETE",
        headers: headers()
      });
      if (!response.ok) throw new Error(`Reset failed ${response.status}`);
      state.marks.clear();
      state.syncStatus = "Reset";
      render();
      paintBadges();
    } catch (error) {
      state.syncStatus = "Reset failed";
      render();
    }
  }

  function allParticipants() {
    const names = new Map();
    [...state.detectedNames, ...state.customNames].forEach((name) => {
      const key = participantKey(name);
      if (key) names.set(key, normalizeName(name));
    });
    state.marks.forEach((row, key) => {
      if (row.marked || names.has(key)) names.set(key, row.participant_name);
    });
    return [...names.entries()].sort((a, b) => a[1].localeCompare(b[1]));
  }

  function ensureUi() {
    if (root) return;

    root = document.createElement("aside");
    root.id = "meet-x-marker-root";
    root.innerHTML = `
      <header class="gmx-header">
        <div class="gmx-title-block">
          <strong>Meet X</strong>
          <span class="gmx-meeting">${state.meetingId}</span>
        </div>
        <div class="gmx-header-actions">
          <span class="gmx-count">0/0</span>
          <button class="gmx-icon-btn" type="button" data-action="collapse" title="Collapse">-</button>
        </div>
      </header>
      <div class="gmx-body">
        <div class="gmx-add-row">
          <input class="gmx-name-input" type="text" placeholder="Add name" />
          <button class="gmx-add-btn" type="button">Add</button>
        </div>
        <div class="gmx-list"></div>
        <footer class="gmx-footer">
          <span class="gmx-status"></span>
          <button class="gmx-reset-btn" type="button">Reset</button>
        </footer>
      </div>
    `;

    body = root.querySelector(".gmx-body");
    countEl = root.querySelector(".gmx-count");
    statusEl = root.querySelector(".gmx-status");

    root.querySelector("[data-action='collapse']").addEventListener("click", () => {
      state.collapsed = !state.collapsed;
      render();
    });

    root.querySelector(".gmx-add-btn").addEventListener("click", () => {
      const input = root.querySelector(".gmx-name-input");
      const name = normalizeName(input.value);
      if (!name) return;
      state.customNames.add(name);
      input.value = "";
      render();
    });

    root.querySelector(".gmx-name-input").addEventListener("keydown", (event) => {
      if (event.key === "Enter") root.querySelector(".gmx-add-btn").click();
    });

    root.querySelector(".gmx-reset-btn").addEventListener("click", () => {
      if (confirm("Clear all X marks for this meeting?")) resetMeeting();
    });

    document.documentElement.appendChild(root);
  }

  function render() {
    ensureUi();
    const rows = allParticipants();
    const markedCount = rows.filter(([key]) => {
      const mark = state.marks.get(key);
      return Boolean(mark && mark.marked);
    }).length;

    root.classList.toggle("is-collapsed", state.collapsed);
    body.hidden = state.collapsed;
    root.querySelector("[data-action='collapse']").textContent = state.collapsed ? "+" : "-";
    countEl.textContent = `${markedCount}/${rows.length}`;
    statusEl.textContent = state.syncStatus;

    const signature = JSON.stringify({
      rows,
      marks: [...state.marks.entries()].map(([key, row]) => [key, row.marked, row.updated_at]),
      collapsed: state.collapsed,
      sync: state.syncStatus
    });
    if (signature === lastRendered) return;
    lastRendered = signature;

    const list = root.querySelector(".gmx-list");
    list.replaceChildren();

    if (!rows.length) {
      const empty = document.createElement("p");
      empty.className = "gmx-empty";
      empty.textContent = "Open the people panel or add names manually.";
      list.appendChild(empty);
      return;
    }

    rows.forEach(([key, name]) => {
      const mark = state.marks.get(key);
      const isMarked = Boolean(mark && mark.marked);

      const row = document.createElement("div");
      row.className = "gmx-row";
      row.dataset.marked = String(isMarked);

      const button = document.createElement("button");
      button.type = "button";
      button.className = "gmx-x-btn";
      button.textContent = "X";
      button.title = isMarked ? `Unmark ${name}` : `Mark ${name} as already gone`;
      button.addEventListener("click", () => setMarked(name, !isMarked));

      const label = document.createElement("span");
      label.className = "gmx-name";
      label.textContent = name;

      const meta = document.createElement("span");
      meta.className = "gmx-meta";
      meta.textContent = isMarked ? "gone" : "";

      row.append(button, label, meta);
      list.append(row);
    });
  }

  function paintBadges() {
    document.querySelectorAll(".gmx-inline-badge").forEach((badge) => badge.remove());

    const markedNames = [...state.marks.values()]
      .filter((row) => row.marked)
      .map((row) => normalizeName(row.participant_name))
      .filter(Boolean);

    if (!markedNames.length) return;

    document.querySelectorAll("[aria-label], [data-self-name]").forEach((el) => {
      const label = `${el.getAttribute("aria-label") || ""} ${el.getAttribute("data-self-name") || ""}`;
      const match = markedNames.find((name) => label.toLowerCase().includes(name.toLowerCase()));
      if (!match || el.querySelector(".gmx-inline-badge")) return;

      const rect = el.getBoundingClientRect();
      if (rect.width < 40 || rect.height < 20) return;

      const style = window.getComputedStyle(el);
      if (style.position === "static") el.style.position = "relative";

      const badge = document.createElement("span");
      badge.className = "gmx-inline-badge";
      badge.textContent = "X";
      badge.title = `${match} already went`;
      el.appendChild(badge);
    });
  }

  function start() {
    ensureUi();
    scrapeParticipants();
    fetchMarks();
    setInterval(scrapeParticipants, SCRAPE_MS);
    setInterval(fetchMarks, POLL_MS);
  }

  start();
})();
